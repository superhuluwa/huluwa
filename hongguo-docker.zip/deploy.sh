#!/bin/bash
# 一键部署 + 验证
# 用法: bash deploy.sh
set -uo pipefail
cd "$(dirname "$0")"

echo "=============================================="
echo " 红果签名服务 — 部署"
echo "=============================================="
echo

# 1. 前置自检
if [ -f preflight.sh ]; then
    echo "[1/4] 环境自检"
    bash preflight.sh
    rc=$?
    if [ "${rc}" -ne 0 ]; then
        echo
        echo "自检未通过，请先按上面的提示修复。"
        echo "确认要继续？(y/N)"
        read -r ans
        [ "${ans}" != "y" ] && exit 1
    fi
else
    echo "[1/4] 跳过自检（preflight.sh 不存在）"
fi

# 2. 配置
echo
echo "[2/4] 准备配置"
if [ ! -f .env ]; then
    cp .env.example .env
    echo "  已创建 .env"
else
    echo "  .env 已存在"
fi

if [ ! -d apk ] || [ -z "$(ls apk/*.apk 2>/dev/null)" ]; then
    echo "  ✗ apk/ 目录里没有 APK"
    echo
    echo "  本部署包不含 APK，请自行放入："
    echo "    cp /path/to/base.apk apk/base.apk"
    echo "    ls -lh apk/base.apk    # 确认约 138 MB"
    echo
    echo "  要求：红果 7.3.9.32 单 APK（非 split），含 arm64-v8a 原生库"
    exit 1
fi
echo "  APK: $(ls apk/*.apk 2>/dev/null | xargs -n1 basename | tr '\n' ' ')"

# 3. 构建并启动
echo
echo "[3/4] 构建并启动容器"
echo "  首次构建 + QEMU 启动 Android 需要较长时间（10-20 分钟）"
docker compose up -d --build
if [ $? -ne 0 ]; then
    echo "  ✗ 启动失败，查看日志: docker compose logs"
    exit 1
fi

# 4. 等待并验证
echo
echo "[4/4] 等待服务就绪并验证"
echo "  轮询 /health（最多 20 分钟）..."
python3 verify.py --quick 2>/dev/null || \
    python verify.py --quick 2>/dev/null || true

ok=0
for i in $(seq 1 120); do
    if python3 -c "
import urllib.request,json,sys
try:
    with urllib.request.urlopen('http://127.0.0.1:8901/health',timeout=50) as r:
        d=json.loads(r.read())
    sys.exit(0 if d.get('ok') else 1)
except Exception:
    sys.exit(1)
" 2>/dev/null; then
        ok=1
        break
    fi
    printf "."
    sleep 10
done
echo

if [ "${ok}" = "1" ]; then
    echo "  ✓ 服务已就绪，执行完整验证"
    echo
    python3 verify.py 2>/dev/null || python verify.py
else
    echo "  ✗ 超时。请检查:"
    echo "    docker compose ps"
    echo "    docker compose logs -f signer"
    echo "    docker compose logs android | tail -50"
    exit 1
fi

echo
echo "=============================================="
echo " 完成"
echo "  服务地址: http://127.0.0.1:8901"
echo "  验证脚本: python verify.py"
echo "=============================================="
