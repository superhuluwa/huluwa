# 红果免费短剧 签名服务（Docker 自包含版）

> **一句话**：容器内跑完整 Android + 红果 App + Frida，对外提供 HTTP 签名接口。
> 不连接任何手机/模拟器。

---

## 0. 给接手者（人或 AI）的快速上下文

如果你要接手这个项目，先读这一节，能省下大量摸索。

### 0.1 项目目标

调用红果免费短剧（`com.phoenix.read` 7.3.9.32）的搜索接口 `search/tab`，
拿到真实搜索结果。难点在于接口需要一组签名请求头，由 App 内的
`libmetasec_ml.so` 生成。

### 0.2 已经确认的关键事实（不要重复验证）

| 事实 | 证据 |
|---|---|
| **`search/page` 已废弃** | App 全程 0 次调用；58 个不同 path 中不存在；任何签名都返回空 |
| **真正可用的搜索接口是 `search/tab`** | 返回 `code=0` + 完整搜索结果 |
| **真正的门槛是 `X-Medusa` + `X-Helios`** | 只带这 2 个头 → 100,270 字节；只带 Gorgon 4 个头 → 0 |
| **`X-Gorgon`/`X-Khronos`/`X-Argus`/`X-Ladon` 对 search/tab 无贡献** | 加上去字节数不变 |
| **`X-Argus` = little-endian(`X-Khronos`)** | 174/174 样本验证 |
| **签名全字节完整性保护** | 篡改任意 1 字节（含时间戳 +1 秒）→ 失效 |
| **签名含随机/时间，每次不同** | 同一 URL 连续签 5 次，Medusa 933/963 字节不同 |
| **签名有效期 > 1 小时** | 抓取 61.8 分钟后重放仍返回 100KB |
| **签名绑定 path + 全部 query 参数** | 改 query/offset/count/_rticket 任一 → 失效 |
| **签名不绑定 host** | sinfonlinea ↔ sinfonlineb 互换仍有效 |

### 0.3 为什么必须调 App，不能纯算法还原

`X-Medusa` 967 字节中只有前 20 字节是明文结构：

```
[0:4]   = LE(unix秒)
[4:8]   = ts XOR 0xCA4F4B28
[8:12]  = ts XOR 0x430D754C
[12:16] = ts XOR 0x2CAEB53A
[16:20] = ts XOR 0x56CC6D27
[20:]   = 947 字节加密（熵 7.79 bits/byte）
```

剩余部分 + `X-Helios`（36 字节）是加密数据，密钥派生自设备指纹与
VM 运行时状态。已尝试并失败的路径：

- unicorn 全量仿真 `libmetasec_ml.so`（推进到 VM 执行 104 次派发，但 VM 依赖整进程堆，无法自洽）
- 样本复用 / 篡改 / 交叉组合（全部失效）

**结论：必须让 App 自己算。** 本方案通过 Frida 调用 App 的 Java 层方法拿到结果。

### 0.4 技术路径（为什么 hook Java 层而不是 native）

App 的签名入口在 Java 层有一个干净的包装方法：

```java
com.bytedance.frameworks.baselib.network.http.NetworkParams
    .tryAddSecurityFactor(String url, Map<String, List<String>> headers)
    → Map<String, String>   // 返回 6 个签名头
```

Frida 通过 Java Bridge 直接调它，**完全不进入 native 层**，因此：

- 不需要逆向 `.so`
- 不需要处理控制流平坦化 / 字节码 VM
- 不需要关心 JNI 细节

这是本项目能跑通的核心。

---

## 1. 环境要求

### 1.1 硬性要求

| 项目 | 要求 | 说明 |
|---|---|---|
| 架构 | **arm64 优先**，x86_64 需仿真 | 见下方说明 |
| KVM | x86_64 仿真时需要 | `/dev/kvm` 可访问 |
| binder | redroid 必需 | `binder_linux` 内核模块 |
| 内存 | ≥ 8 GB | Android 分配 6 GB |
| CPU | ≥ 8 核 | QEMU 仿真 CPU 密集 |
| Docker | 20.10+ | 需 compose v2 |

### 1.2 关于架构（最重要）

红果 APK **只含 arm64-v8a 原生库**（117 个 `.so`，无任何 x86_64）。

因此：

- **arm64 服务器**（如 Oracle ARM、阿里云 ARM 实例）→ 原生运行，性能最佳
- **x86_64 服务器**（如 AMD R7 7845HS）→ 需 QEMU 用户态仿真，性能下降 5–10 倍

**为什么不直接用 x86_64 版 Android？**

x86_64 Android 无法加载 arm64 的 `.so`。虽然可以用 libhoudini 翻译层
（雷电模拟器就是这么做的），但 redroid 官方镜像**不包含**翻译层，
App 会直接崩溃在 so 加载阶段。

---

## 2. 服务器一次性准备

```bash
# ---- 1. arm64 仿真（x86_64 服务器必做）----
docker run --privileged --rm tonistiigi/binfmt --install arm64
# 验证
ls /proc/sys/fs/binfmt_misc/qemu-aarch64

# ---- 2. binder 内核模块（redroid 必需）----
sudo modprobe binder_linux devices="binder,hwbinder,vndbinder"
echo 'binder_linux' | sudo tee /etc/modules-load.d/binder.conf

# ---- 3. 内核参数 ----
sudo sysctl -w vm.max_map_count=262144
echo 'vm.max_map_count=262144' | sudo tee /etc/sysctl.d/99-redroid.conf

# ---- 4. 确认 Docker ----
docker --version
docker compose version
```

---

## 3. 部署

### 3.1 准备文件

```
docker/
├── docker-compose.yml
├── .env.example
├── preflight.sh          # 环境自检
├── deploy.sh             # 一键部署+验证
├── verify.py             # 独立验证脚本
├── README.md             # 本文档
├── apk/                  # ← 放红果 APK（需自己创建）
│   └── base.apk
├── android/
│   └── Dockerfile        # redroid arm64 运行时
└── signer/
    ├── Dockerfile        # 签名服务镜像
    ├── entrypoint.sh     # 启动编排
    ├── sign_server.py    # 签名 HTTP 服务
    └── docker-healthcheck.sh
```

### 3.2 放置 APK（必须，包里不含 APK）

**本部署包不包含 APK**（体积大 + 版权原因），需要自己放进去：

```bash
cp /path/to/base.apk apk/base.apk
ls -lh apk/base.apk      # 确认约 138 MB
```

要求：

| 项目 | 要求 |
|---|---|
| 版本 | 红果免费短剧 7.3.9.32 |
| 包名 | `com.phoenix.read` |
| 形式 | **单 APK**（不是 split APK） |
| 架构 | 含 `arm64-v8a` 原生库（红果本身就是） |

校验（可选）：

```bash
unzip -l apk/base.apk | grep libmetasec_ml.so
# 应看到 lib/arm64-v8a/libmetasec_ml.so
```

> `apk/` 目录里有一个 `PUT_APK_HERE.txt` 占位文件，是空目录占位用的，
> 不影响使用。如果红果是 split APK，把全部 `.apk` 放进去并调整
> `.env` 的 `APK_PATH`（需改 entrypoint 用 `install-multiple`）。

### 3.3 配置

```bash
cp .env.example .env
vi .env
```

`.env` 说明：

| 变量 | 默认 | 说明 |
|---|---|---|
| `SIGN_PORT` | 8901 | 对外 HTTP 端口 |
| `APK_DIR` | ./apk | APK 目录 |
| `APK_PATH` | /apk/base.apk | 容器内 APK 路径 |
| `TARGET_PKG` | com.phoenix.read | 目标包名 |
| `BOOT_TIMEOUT` | 900 | Android 启动最长等待（秒） |
| `APP_WARMUP` | 45 | App 启动后等待初始化（秒） |

### 3.4 一键部署（推荐）

```bash
bash deploy.sh
```

它会依次：自检 → 检查 APK → 构建启动 → 轮询等待 → 完整验证。

### 3.5 手动部署

```bash
bash preflight.sh              # 自检
docker compose up -d --build   # 构建启动
docker compose logs -f signer  # 看日志
```

首次启动时间预期：

| 阶段 | arm64 原生 | x86_64 QEMU |
|---|---|---|
| 镜像构建 | 2–5 min | 3–8 min |
| Android 启动 | 1–3 min | **8–20 min** |
| App 冷启动 | 10–30 s | 1–3 min |

看到以下输出即成功：

```
[OK] 签名就绪
 HTTP: http://0.0.0.0:8901
```

---

## 4. 验证方法（重要）

### 4.1 用自带的 verify.py（推荐）

```bash
python3 verify.py
```

输出示例：

```
==================================================================
 签名服务验证 — http://127.0.0.1:8901
==================================================================

  ✓ 服务可达
  ✓ 健康检查 /health          headers=X-Argus,X-Gorgon,X-Helios,...
  ✓ 含 X-Medusa
  ✓ 含 X-Helios
  ✓ /info                    frida=16.4.10 pkg=com.phoenix.read
  ✓ /sign 返回签名            keys=6
  ✓   X-Khronos              1793783323
  ✓   X-Argus                1f7qag==
  ✓   X-Gorgon               8404...
  ✓   X-Ladon                ...
  ✓ /verify 端到端            code=0 bytes=68118 items=6
  ✓   真实数据                first_book_id=7689345330373987390

==================================================================
 结论: 全部通过 ✓  签名服务可用
==================================================================
```

选项：

```bash
python3 verify.py --quick              # 只测 /health
python3 verify.py --json               # 机器可读
python3 verify.py --server http://IP:8901
```

退出码：`0` 全通过 / `1` 有失败 / `2` 无法连接。

### 4.2 手动 curl 验证

```bash
# 1) 健康检查 —— 会真实签一次名
curl http://127.0.0.1:8901/health
# 期望: {"ok": true, "headers": ["X-Argus","X-Gorgon","X-Helios","X-Khronos","X-Ladon","X-Medusa"]}

# 2) 环境信息
curl http://127.0.0.1:8901/info

# 3) 生成签名
curl -X POST http://127.0.0.1:8901/sign \
     -H 'Content-Type: application/json' \
     -d '{"url":"https://api5-normal-sinfonlineb.fqnovel.com/reading/bookapi/search/tab/v?aid=8662&query=test"}'
# 期望: 6 个头

# 4) 端到端验证（最关键）
curl -X POST http://127.0.0.1:8901/verify \
     -H 'Content-Type: application/json' -d '{}'
# 期望: {"ok": true, "code": 0, "bytes": 68118, "items": 6, ...}
```

### 4.3 判读标准

| 接口 | 通过条件 |
|---|---|
| `/health` | HTTP 200 且 `ok=true` |
| `/sign` | 返回 JSON 含 `X-Medusa` 和 `X-Helios` |
| `/verify` | HTTP 200 且 `ok=true`、`code=0`、`bytes>1000` |

**`/verify` 通过 = 真正可用**，因为它完整走了一遍「签名 → 请求 → 服务端接受 → 返回真实数据」。

---

## 5. HTTP 接口规范

### 5.1 `GET /health`

```json
{
  "ok": true,
  "headers": ["X-Argus","X-Gorgon","X-Helios","X-Khronos","X-Ladon","X-Medusa"],
  "ts": 1793783323
}
```

失败返回 HTTP 503 + `{"ok": false, "error": "..."}`

### 5.2 `GET /info`

```json
{
  "hasNetworkParams": true,
  "className": "com.bytedance.frameworks.baselib.network.http.NetworkParams",
  "pkg": "com.phoenix.read",
  "model": "SM-S9310",
  "sdkInt": "34",
  "frida_version": "16.4.10",
  "target_pkg": "com.phoenix.read",
  "frida_host": "127.0.0.1:27042",
  "endpoints": ["GET /health","GET /info","POST /sign","POST /verify"]
}
```

### 5.3 `POST /sign`

请求：

```json
{"url": "https://api5-normal-sinfonlineb.fqnovel.com/reading/bookapi/search/tab/v?aid=8662&query=test"}
```

返回（HTTP 200）：

```json
{
  "X-Gorgon": "840460274485...",
  "X-Khronos": "1793783323",
  "X-Argus": "1f7qag==",
  "X-Ladon": "ZDaNOg==",
  "X-Medusa": "Au7qaiqlpaBOm+cp...",
  "X-Helios": "3w9AKQZM48F14u4..."
}
```

**注意**：签名与 URL 逐字节绑定。改了 URL 的任何部分（含 `_rticket`）
都必须重新签。

### 5.4 `POST /verify`

请求（body 可为空，用内置 URL）：

```json
{"url": "..."}   // 可选
```

返回：

```json
{
  "ok": true,
  "url": "https://...",
  "steps": [
    {"step": "sign", "ok": true, "ms": 45, "headers": [...],
     "has_medusa": true, "has_helios": true},
    {"step": "http", "ok": true, "ms": 320, "http_status": 200,
     "bytes": 68118, "code": 0, "tabs": 7, "items": 6}
  ],
  "http_status": 200,
  "bytes": 68118,
  "code": 0,
  "tabs": 7,
  "items": 6,
  "first_book_id": "7689345330373987390",
  "total_ms": 365
}
```

失败时 `ok=false`，并带 `stage`（`sign`/`http`/`parse`）和 `error`。

---

## 6. 客户端调用示例

### 6.1 Python

```python
import json, urllib.request, urllib.parse, gzip, time

SIGN = "http://127.0.0.1:8901"
UA = ("com.phoenix.read/73932 (Linux; U; Android 14; zh_CN; SM-S9310; "
      "Build/UQ1A.240205.06091433;tt-ok/3.12.13.20)")

def sign(url):
    req = urllib.request.Request(
        SIGN + "/sign", data=json.dumps({"url": url}).encode(),
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read())

def search(query):
    params = {
        "device_platform": "android", "aid": "8662", "app_name": "novelread",
        "version_code": "73932", "version_name": "7.3.9.32",
        "manifest_version_code": "73932", "update_version_code": "73932",
        "channel": "vivo_8662_64", "os": "android", "ssmix": "a",
        "device_type": "SM-S9310", "device_brand": "SAMSUNG",
        "language": "zh", "os_api": "34", "os_version": "14",
        "resolution": "1440*2560", "dpi": "640", "ac": "wifi",
        "device_id": "305040037566937", "iid": "305040037571033",
        "cdid": "432b64a9-68af-457b-b8db-16032c6d6427",
        "host_abi": "arm64-v8a", "dragon_device_type": "phone",
        "user_is_login": "0", "bookshelf_search_plan": "4",
        "bookstore_tab": "-1", "search_source": "1",
        "use_correct": "true", "is_first_enter_search": "true",
        "query": query, "offset": "0", "count": "0",
        "_rticket": str(int(time.time() * 1000)),
    }
    url = ("https://api5-normal-sinfonlineb.fqnovel.com"
           "/reading/bookapi/search/tab/v?" + urllib.parse.urlencode(params))
    h = {"User-Agent": UA, "Accept-Encoding": "gzip"}
    h.update(sign(url))
    with urllib.request.urlopen(urllib.request.Request(url, headers=h),
                                timeout=40) as r:
        raw = r.read()
    if raw[:2] == b"\x1f\x8b":
        raw = gzip.decompress(raw)
    return json.loads(raw)

data = search("赘婿")
print("code =", data["code"])
for tab in data["search_tabs"]:
    print(tab["title"], len(tab["data"]))
```

### 6.2 curl

```bash
URL='https://api5-normal-sinfonlineb.fqnovel.com/reading/bookapi/search/tab/v?aid=8662&query=test'
SIG=$(curl -s -X POST http://127.0.0.1:8901/sign \
      -H 'Content-Type: application/json' -d "{\"url\":\"$URL\"}")

curl -s "$URL" \
  -H "X-Medusa: $(echo $SIG | jq -r '."X-Medusa"')" \
  -H "X-Helios: $(echo $SIG | jq -r '."X-Helios"')" \
  -H "X-Gorgon: $(echo $SIG | jq -r '."X-Gorgon"')" \
  -H "X-Khronos: $(echo $SIG | jq -r '."X-Khronos"')" \
  -H "X-Argus: $(echo $SIG | jq -r '."X-Argus"')" \
  -H "X-Ladon: $(echo $SIG | jq -r '."X-Ladon"')" \
  -H "User-Agent: com.phoenix.read/73932 (Linux; U; Android 14; zh_CN; SM-S9310; Build/UQ1A.240205.06091433;tt-ok/3.12.13.20)"
```

---

## 7. 启动流程（entrypoint.sh）

1. 等待 `android:5555` 的 adb 就绪 + `sys.boot_completed=1`
2. 等 package manager 可用
3. 检查 App 是否已安装，未装则 `adb install -r -g`
4. `adb root` → 推送 `frida-server` 到 `/data/local/tmp/` → 启动
5. `adb forward tcp:27042` 打通容器内访问
6. 启动 App（`monkey -p com.phoenix.read`），等 `pidof` 出现
7. 等 `APP_WARMUP` 秒（让 metasec 初始化）
8. 启动签名 HTTP 服务（`--bind 0.0.0.0`）

---

## 8. 故障排查

### 8.1 启动阶段

| 现象 | 原因 | 解决 |
|---|---|---|
| `exec format error` | 未注册 arm64 仿真 | `docker run --privileged --rm tonistiigi/binfmt --install arm64` |
| Android 一直不起来 | binder 未加载 | `sudo modprobe binder_linux devices="binder,hwbinder,vndbinder"` |
| `INSTALL_FAILED_NO_MATCHING_ABIS` | 用了 x86_64 镜像 | 确认 compose 里 `platform: linux/arm64` |
| `INSTALL_FAILED_INSUFFICIENT_STORAGE` | 数据卷太小 | 加大 `hongguo-data` 或清理 |
| 容器 OOM | 内存不足 | `mem_limit` 提到 6–8g，宿主机 ≥12GB |

### 8.2 运行阶段

| 现象 | 原因 | 解决 |
|---|---|---|
| `/health` 返回 503 | App 未就绪 | 等更久；调大 `APP_WARMUP` |
| `找不到 App 进程` | App 崩溃 | `docker compose logs android`；看 logcat |
| 签名超时 | QEMU 太慢 | 提高 `timeout`，减少并发 |
| `frida 脚本加载失败` | 版本不匹配 | 统一 `FRIDA_VERSION` 与 pip 依赖 |
| `/sign` 返回空 | metasec 未初始化 | 重启容器，或手动点一下 App |

### 8.3 诊断命令

```bash
# 容器状态
docker compose ps

# 签名服务日志
docker compose logs -f signer

# Android 日志
docker compose logs android | tail -100

# 进 Android 看进程
docker exec -it hongguo-android "ps -A | grep phoenix"

# 看 App 是否在跑
docker exec -it hongguo-signer adb -s android:5555 shell "pidof com.phoenix.read"

# 看 frida-server
docker exec -it hongguo-signer adb -s android:5555 shell "pgrep -f frida-server"

# App 崩溃日志
docker exec -it hongguo-signer adb -s android:5555 logcat -d | grep -iE "phoenix|metasec" | tail -60

# 检查 so 是否加载成功（验证架构）
docker exec -it hongguo-signer adb -s android:5555 shell \
  "cat /proc/\$(pidof com.phoenix.read)/maps | grep metasec"
```

最后一条很关键：如果能查到 `libmetasec_ml.so`，说明架构正确、so 加载成功。

---

## 9. 性能与容量

QEMU 仿真下的实际数字（x86_64 宿主机，R7 7845HS 级别）：

| 指标 | 值 |
|---|---|
| 单次 `/sign` | 200 ms – 2 s |
| 单次 `/verify` | 0.5 – 3 s |
| 可持续 QPS | 1–3（单实例） |
| CPU 占用 | 持续 4–8 核 |

**arm64 原生服务器**可提升 5–10 倍。

如需更高并发：多开 signer 容器（共享同一个 android），或换成 arm64 服务器。

---

## 10. 替代方案

如果 QEMU 方案跑不动，按推荐度：

| 方案 | 优点 | 缺点 |
|---|---|---|
| **换 arm64 服务器** | 原生性能，无需仿真 | 需采购/迁移 |
| **arm64 开发板/手机 + Termux+Docker** | 成本低 | 运维麻烦 |
| **连接真机/模拟器模式** | 已验证可用、性能好 | 需保持设备在线 |

第三种就是把 `sign_server.py` 直接跑在能连到设备的机器上：

```bash
python sign_server.py --serial <设备序列号>
```

代码完全一样，只是不放在容器里。

---

## 11. 合规声明

本项目仅用于**协议互操作性研究**：

- 只读取公开提供的书籍元数据
- 不得用于批量爬取、商业分发或任何侵犯版权用途
- 请遵守目标服务的使用条款

---

## 12. 文件清单

| 文件 | 作用 |
|---|---|
| `docker-compose.yml` | 编排：`android`（redroid arm64）+ `signer`（签名服务） |
| `.env.example` | 配置模板 |
| `preflight.sh` | 环境自检（8 项） |
| `deploy.sh` | 一键部署 + 等待 + 验证 |
| `verify.py` | 独立验证脚本（不需要 frida） |
| `android/Dockerfile` | redroid Android 14 arm64 |
| `signer/Dockerfile` | Python + adb + frida 16.4.10 |
| `signer/entrypoint.sh` | 8 步启动编排 |
| `signer/sign_server.py` | 签名 HTTP 服务 |
| `signer/docker-healthcheck.sh` | 容器健康检查 |
