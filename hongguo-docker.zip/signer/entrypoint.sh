#!/bin/bash
# 算法容器入口：
#   1. 等待 redroid (Android) 的 adb 就绪
#   2. 安装并启动红果 App
#   3. 推送并启动 frida-server（root）
#   4. 启动签名 HTTP 服务
set -euo pipefail

ADB_TARGET="${ADB_TARGET:-redroid:5555}"
APK_PATH="${APK_PATH:-/apk/base.apk}"
TARGET_PKG="${TARGET_PKG:-com.phoenix.read}"
FRIDA_SERVER_BIN="${FRIDA_SERVER_BIN:-/opt/frida/frida-server}"
FRIDA_PORT="${FRIDA_PORT:-27042}"
PORT="${PORT:-8901}"
BOOT_TIMEOUT="${BOOT_TIMEOUT:-900}"
APP_WARMUP="${APP_WARMUP:-45}"

log() { echo "[entrypoint] $*"; }

# ---------------- 1. 等待 Android 启动 ----------------
log "连接 adb: ${ADB_TARGET}"
adb start-server >/dev/null 2>&1 || true

deadline=$(( $(date +%s) + BOOT_TIMEOUT ))
connected=0
while [ "$(date +%s)" -lt "$deadline" ]; do
    if adb connect "${ADB_TARGET}" 2>&1 | grep -qE "connected|already connected"; then
        if adb -s "${ADB_TARGET}" shell getprop sys.boot_completed 2>/dev/null | tr -d '\r' | grep -q "^1$"; then
            connected=1
            break
        fi
    fi
    sleep 3
done

if [ "${connected}" != "1" ]; then
    log "错误：Android 在 ${BOOT_TIMEOUT}s 内未启动完成"
    adb devices || true
    exit 1
fi
log "Android 已启动"

SERIAL="${ADB_TARGET}"
ADB="adb -s ${SERIAL}"

# 等包管理器可用
deadline=$(( $(date +%s) + 180 ))
while [ "$(date +%s)" -lt "$deadline" ]; do
    if ${ADB} shell pm list packages >/dev/null 2>&1; then break; fi
    sleep 3
done

# ---------------- 2. 安装 App ----------------
if ${ADB} shell pm list packages 2>/dev/null | grep -q "package:${TARGET_PKG}"; then
    log "App 已安装: ${TARGET_PKG}"
else
    if [ ! -f "${APK_PATH}" ]; then
        log "错误：找不到 APK: ${APK_PATH}"
        log "请通过 volume 挂载 APK 到 ${APK_PATH}"
        exit 1
    fi
    log "安装 APK: ${APK_PATH}"
    ${ADB} install -r -g "${APK_PATH}" || {
        log "错误：APK 安装失败（若是 split APK，请挂载整个目录并改用 install-multiple）"
        exit 1
    }
fi

# ---------------- 3. 启动 frida-server ----------------
log "推送 frida-server"
${ADB} root >/dev/null 2>&1 || true
sleep 2
${ADB} push "${FRIDA_SERVER_BIN}" /data/local/tmp/frida-server >/dev/null
${ADB} shell "chmod 755 /data/local/tmp/frida-server"

# kill 旧的
${ADB} shell "su -c 'pkill -f frida-server'" >/dev/null 2>&1 || true
sleep 1
log "启动 frida-server"
${ADB} shell "su -c 'nohup /data/local/tmp/frida-server -l 0.0.0.0:${FRIDA_PORT} >/dev/null 2>&1 &'"

# 端口转发：容器内 127.0.0.1:27042 -> 设备 27042
${ADB} forward tcp:${FRIDA_PORT} tcp:${FRIDA_PORT} >/dev/null 2>&1 || true

# 等 frida-server 起来
sleep 3
if ! ${ADB} shell "pgrep -f frida-server" >/dev/null 2>&1; then
    log "警告：frida-server 可能未启动，继续尝试"
fi

# ---------------- 4. 启动 App（让 metasec 初始化） ----------------
log "启动 App: ${TARGET_PKG}"
${ADB} shell monkey -p "${TARGET_PKG}" -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1 || true

# 等待 App 进程出现
deadline=$(( $(date +%s) + 120 ))
pkg_pid=""
while [ "$(date +%s)" -lt "$deadline" ]; do
    pkg_pid="$(${ADB} shell pidof "${TARGET_PKG}" 2>/dev/null | tr -d '\r')"
    if [ -n "${pkg_pid}" ]; then break; fi
    sleep 2
done

if [ -z "${pkg_pid}" ]; then
    log "错误：App 未启动"
    exit 1
fi
log "App pid=${pkg_pid}"

# metasec 需要一点时间初始化，稍微等
log "等待 App 初始化（${APP_WARMUP}s）..."
sleep "${APP_WARMUP}"

# ---------------- 5. 启动签名服务 ----------------
log "启动签名 HTTP 服务 :${PORT}"
export FRIDA_HOST="127.0.0.1:${FRIDA_PORT}"
export ADB_SERIAL="${SERIAL}"
export TARGET_PKG="${TARGET_PKG}"

exec python /app/sign_server.py --bind 0.0.0.0 --port "${PORT}"
