#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
签名服务验证脚本
================

独立验证签名服务是否真正可用。不依赖 frida，只用标准库发 HTTP 请求。

用法：
  python verify.py                        # 验证 http://127.0.0.1:8901
  python verify.py --server http://1.2.3.4:8901
  python verify.py --json                 # 机器可读输出
  python verify.py --quick                # 只测 /health

退出码：
  0  全部通过
  1  有失败项
  2  无法连接服务
"""
import sys
import json
import argparse
import urllib.request
import urllib.error


def req(url, data=None, timeout=60):
    body = json.dumps(data).encode() if data is not None else None
    r = urllib.request.Request(
        url, data=body,
        headers={"Content-Type": "application/json"} if body else {})
    try:
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            raw = resp.read()
            status = resp.status
    except urllib.error.HTTPError as e:
        raw = e.read()
        status = e.code
    try:
        return status, json.loads(raw)
    except Exception:
        return status, {"__raw": raw[:300].decode("utf-8", "ignore")}


def main():
    ap = argparse.ArgumentParser(description="签名服务验证")
    ap.add_argument("--server", default="http://127.0.0.1:8901",
                    help="签名服务地址（默认 http://127.0.0.1:8901）")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    ap.add_argument("--quick", action="store_true", help="只测 /health")
    args = ap.parse_args()

    base = args.server.rstrip("/")
    report = {"server": base, "checks": []}
    failed = 0

    def rec(name, ok, detail=None):
        nonlocal failed
        report["checks"].append({"name": name, "ok": ok, "detail": detail})
        if not ok:
            failed += 1
        if not args.json:
            print("  %s %-26s %s" % ("✓" if ok else "✗", name,
                                     detail if detail else ""))

    if not args.json:
        print("=" * 66)
        print(" 签名服务验证 — %s" % base)
        print("=" * 66)
        print()

    # --- 1. 连通性 ---
    try:
        st, body = req(base + "/health", timeout=90)
        reachable = True
    except Exception as e:
        if not args.json:
            print("  ✗ 无法连接服务: %s" % e)
            print()
            print("排查：")
            print("  1. docker compose ps          # 容器是否在跑")
            print("  2. docker compose logs signer # 看启动日志")
            print("  3. 确认端口: %s" % base)
        report["error"] = str(e)
        if args.json:
            print(json.dumps(report, ensure_ascii=False, indent=2))
        return 2

    rec("服务可达", True)
    rec("健康检查 /health", bool(body.get("ok")),
        "headers=%s" % ",".join(body.get("headers") or [])
        if body.get("ok") else str(body.get("error") or body)[:80])

    # 关键头
    hdrs = body.get("headers") or []
    rec("含 X-Medusa", "X-Medusa" in hdrs)
    rec("含 X-Helios", "X-Helios" in hdrs)

    if args.quick:
        report["ok"] = failed == 0
        if args.json:
            print(json.dumps(report, ensure_ascii=False, indent=2))
        else:
            print()
            print("结论: %s" % ("通过" if failed == 0 else "失败"))
        return 0 if failed == 0 else 1

    # --- 2. /info ---
    try:
        st, info = req(base + "/info", timeout=30)
        rec("/info", st == 200 and "frida_version" in info,
            "frida=%s pkg=%s" % (info.get("frida_version"), info.get("pkg")))
    except Exception as e:
        rec("/info", False, str(e)[:60])

    # --- 3. /sign ---
    test_url = ("https://api5-normal-sinfonlineb.fqnovel.com"
                "/reading/bookapi/search/tab/v?aid=8662&query=test&offset=0")
    try:
        st, sig = req(base + "/sign", {"url": test_url}, timeout=90)
        ok = st == 200 and isinstance(sig, dict) and "X-Medusa" in sig
        rec("/sign 返回签名", ok,
            "keys=%d" % len(sig) if isinstance(sig, dict) else str(sig)[:60])
        if ok:
            for k in ("X-Khronos", "X-Argus", "X-Gorgon", "X-Ladon"):
                rec("  %s" % k, k in sig,
                    str(sig.get(k, ""))[:40])
    except Exception as e:
        rec("/sign", False, str(e)[:60])
        sig = None

    # --- 4. /verify 端到端 ---
    try:
        st, ver = req(base + "/verify", {}, timeout=120)
        ok = st == 200 and ver.get("ok") is True
        rec("/verify 端到端", ok,
            "code=%s bytes=%s items=%s"
            % (ver.get("code"), ver.get("bytes"), ver.get("items"))
            if ok else str(ver.get("error") or ver)[:80])
        if ok and ver.get("first_book_id"):
            rec("  真实数据", True, "first_book_id=%s" % ver["first_book_id"])
    except Exception as e:
        rec("/verify", False, str(e)[:60])

    report["ok"] = failed == 0
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print()
        print("=" * 66)
        if failed == 0:
            print(" 结论: 全部通过 ✓  签名服务可用")
        else:
            print(" 结论: %d 项失败 ✗" % failed)
            print()
            print(" 常见原因:")
            print("  - App 未启动 / 崩溃    -> docker compose logs android")
            print("  - frida 版本不匹配     -> 统一 FRIDA_VERSION")
            print("  - Android 还在启动中   -> 等几分钟再试")
            print("  - App 上下文未初始化   -> 调大 APP_WARMUP")
        print("=" * 66)

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
