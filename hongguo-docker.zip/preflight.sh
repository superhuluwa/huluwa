#!/bin/bash
# 部署前自检 —— 针对 AMD R7 7845HS (x86_64) + arm64 Android 仿真
set -uo pipefail

FAIL=0
WARN=0
ok()   { echo "  ✓ $*"; }
bad()  { echo "  ✗ $*"; FAIL=$((FAIL+1)); }
warn() { echo "  ! $*"; WARN=$((WARN+1)); }

echo "=============================================="
echo " 红果签名服务 — 部署前自检"
echo "=============================================="

echo
echo "[1] 宿主机架构"
ARCH=$(uname -m)
echo "     $ARCH"
if [ "${ARCH}" = "x86_64" ] || [ "${ARCH}" = "amd64" ]; then
    warn "x86_64 宿主机 —— 需要 arm64 仿真（下方会检查）"
else
    ok "arm64 宿主机（无需仿真，性能最佳）"
fi

echo
echo "[2] arm64 仿真器（关键！）"
if [ -e /proc/sys/fs/binfmt_misc/qemu-aarch64 ]; then
    ok "binfmt qemu-aarch64 已注册"
    grep -h . /proc/sys/fs/binfmt_misc/qemu-aarch64 2>/dev/null | head -3 | sed 's/^/       /'
else
    bad "未注册 qemu-aarch64 —— arm64 镜像无法启动"
    echo "       修复: docker run --privileged --rm tonistiigi/binfmt --install arm64"
fi

echo
echo "[3] binder 内核模块（redroid 必需）"
if lsmod 2>/dev/null | grep -q binder; then
    ok "binder 已加载"
else
    if find "/lib/modules/$(uname -r)" -name 'binder_linux*' 2>/dev/null | grep -q .; then
        bad "binder 模块存在但未加载"
        echo "       修复: sudo modprobe binder_linux devices=\"binder,hwbinder,vndbinder\""
    else
        warn "未找到 binder 模块（可能已编译进内核，需确认 /dev/binder 存在）"
        [ -e /dev/binder ] && ok "  /dev/binder 存在" || warn "  /dev/binder 不存在"
    fi
fi

echo
echo "[4] Docker"
if command -v docker >/dev/null 2>&1; then
    ok "$(docker --version | head -1)"
    if docker compose version >/dev/null 2>&1; then
        ok "compose 可用"
    else
        bad "docker compose 不可用"
    fi
    # 检查是否支持多架构
    if docker buildx version >/dev/null 2>&1; then
        ok "buildx 可用（多架构构建需要）"
    else
        warn "buildx 不可用"
    fi
else
    bad "未安装 docker"
fi

echo
echo "[5] CPU 与内存"
PHYS=$(grep 'physical id' /proc/cpuinfo 2>/dev/null | sort -u | wc -l)
PHYS=${PHYS:-1}
[ "${PHYS}" -lt 1 ] && PHYS=1
CORES=$(nproc 2>/dev/null || echo 0)
echo "     逻辑核: ${CORES}"
if [ "${CORES}" -ge 8 ]; then
    ok "核心数充足"
else
    warn "建议 >=8 核（QEMU 仿真 CPU 密集）"
fi

MEM_GB=$(awk '/MemTotal/{printf "%.0f", $2/1024/1024}' /proc/meminfo 2>/dev/null || echo 0)
echo "     内存: ${MEM_GB} GB"
if [ "${MEM_GB}" -ge 8 ]; then
    ok "内存充足"
else
    warn "建议 >=8GB（Android 分配 6GB，需留余量）"
fi

echo
echo "[6] 内核参数"
MMC=$(cat /proc/sys/vm/max_map_count 2>/dev/null || echo 0)
echo "     vm.max_map_count = ${MMC}"
if [ "${MMC}" -ge 262144 ]; then
    ok "max_map_count 充足"
else
    warn "建议提高: sudo sysctl -w vm.max_map_count=262144"
fi

echo
echo "[7] APK"
APK_DIR="${APK_DIR:-./apk}"
if [ -d "${APK_DIR}" ]; then
    n=$(find "${APK_DIR}" -maxdepth 1 -name '*.apk' 2>/dev/null | wc -l)
    if [ "${n}" -gt 0 ]; then
        ok "${APK_DIR} 下有 ${n} 个 apk:"
        find "${APK_DIR}" -maxdepth 1 -name '*.apk' -exec basename {} \; | sed 's/^/       /'
    else
        bad "${APK_DIR} 下没有 apk（部署包不含 APK，需自行放入）"
        echo "       放入方式: cp /path/to/base.apk ${APK_DIR}/base.apk"
        echo "       要求: 红果 7.3.9.32 单APK，含 arm64-v8a 原生库"
    fi
else
    bad "APK 目录不存在: ${APK_DIR}"
fi

echo
echo "=============================================="
if [ "${FAIL}" -eq 0 ]; then
    echo " 结论: 可以部署  (警告 ${WARN} 项)"
    echo
    echo " 下一步:"
    echo "   cp .env.example .env"
    echo "   bash preflight.sh --fix-hint"
    echo "   docker compose up -d --build"
    echo "   docker compose logs -f signer"
else
    echo " 结论: 有 ${FAIL} 项必须修复  (警告 ${WARN} 项)"
    echo
    echo " 常见修复:"
    echo "   # arm64 仿真"
    echo "   docker run --privileged --rm tonistiigi/binfmt --install arm64"
    echo
    echo "   # binder"
    echo "   sudo modprobe binder_linux devices=\"binder,hwbinder,vndbinder\""
    echo "   echo 'binder_linux' | sudo tee /etc/modules-load.d/binder.conf"
    echo
    echo "   # 内核参数"
    echo "   sudo sysctl -w vm.max_map_count=262144"
    echo "   echo 'vm.max_map_count=262144' | sudo tee /etc/sysctl.d/99-redroid.conf"
fi
echo "=============================================="

exit "${FAIL}"
